# Pure Glam

Sitio estático con catálogo de productos de belleza, carrito con cantidades, total y checkout por WhatsApp.

## Cómo editar
- Edita `index.html` para cambiar productos (array `PRODUCTS`), colores y textos.
- Cambia `WHATSAPP_NUMBER` al número correcto (ej. 54911XXXXXXX).

## Publicación
- Sube estos archivos a tu repo público en GitHub.
- Activa GitHub Pages: Settings → Pages → Deploy from a branch → main / (root).
- Tu sitio quedará disponible en `https://TU_USUARIO.github.io/REPONAME/`.
