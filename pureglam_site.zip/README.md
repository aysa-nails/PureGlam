# Pure Glam

Página de productos de belleza (pelo, piel, uñas) con carrito y compra vía WhatsApp.

Diseñada y desarrollada con HTML, CSS y JavaScript.
